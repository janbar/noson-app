/*
 *      Copyright (C) 2018-2026 Jean-Luc Barriere
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#ifndef IOSTREAM_H
#define IOSTREAM_H

#include "local_config.h"

namespace NSROOT
{

class OutputStream
{
public:
  virtual int Write(const char * data, int len) = 0;
};

class InputStream
{
public:
  virtual int Read(char * data, int maxlen) = 0;
};

namespace OS
{
class Mutex;
template <typename T> class Condition;
}

class AsyncInputStream : protected InputStream
{
public:
  AsyncInputStream();
  virtual ~AsyncInputStream();
  AsyncInputStream(const AsyncInputStream& other) = delete;
  AsyncInputStream& operator=(const AsyncInputStream& other) = delete;

  int ReadAsync(char * data, int maxlen, unsigned timeout);

protected:
  void SignalReadyRead();

  virtual int BytesAvailable() const  = 0;

private:
  mutable OS::Mutex * m_lock;
  OS::Condition<bool> * m_readyRead;
};

class RingBuffer;
class RingBufferPacket;

class BufferedStream : public OutputStream, public AsyncInputStream
{
public:
  BufferedStream(int capacity);
  virtual ~BufferedStream() override;

  int BytesAvailable() const override;
  bool Overflow() const;

  int Write(const char * data, int len) override;

protected:
  int Read(char * data, int maxlen) override;
  void ClearBuffer();

private:
  RingBuffer * m_buffer;
  RingBufferPacket * m_packet;
  int m_consumed;
};

}

#endif /* IOSTREAM_H */

