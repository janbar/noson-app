/*
 *      Copyright (C) 2014-2019 Jean-Luc Barriere
 *
 *  This file is part of Noson
 *
 *  Noson is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  Noson is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "eventbroker.h"
#include "wsstatic.h"
#include "debug.h"
#include "requestbrokeropaque.h"

using namespace NSROOT;

#define CONNECTION_TIMEOUT  5 // default timeout in seconds

EventBroker::EventBroker(EventHandlerThread* handler, SHARED_PTR<TcpSocket>& sockPtr)
: m_handler(handler)
, m_sockPtr(sockPtr)
{
}

EventBroker::~EventBroker()
{
}

void EventBroker::Process()
{
  if (!m_handler || !m_sockPtr || !m_sockPtr->IsValid())
    return;

  WSRequestBroker rb(m_sockPtr.get(), false, CONNECTION_TIMEOUT);
  std::string resp;

  if (!rb.IsParsed())
  {
    rb.ReplyHead(WS_STATUS_400_Bad_Request);
    rb.ReplyBody(WS_CRLF, WS_CRLF_LEN);
    m_sockPtr->Disconnect();
    return;
  }

  RequestBroker::opaque payload = { m_sockPtr.get(), &rb };
  RequestBroker::handle handle { m_handler, &payload };
  std::vector<RequestBrokerPtr> vect = m_handler->AllRequestBroker();
  for (std::vector<RequestBrokerPtr>::iterator itrb = vect.begin(); itrb != vect.end(); ++itrb)
  {
    // loop until the request is processed
    if ((*itrb)->HandleRequest(&handle))
    {
      m_sockPtr->Disconnect();
      return;
    }
  }

  // default response for "HEAD /"
  if (rb.GetRequestMethod() == WS_METHOD_Head && rb.GetRequestPath().compare("/") == 0)
  {
    WS_STATUS status(WS_STATUS_200_OK);
    resp.append(REQUEST_PROTOCOL " ").append(ws_status_to_numstr(status)).append(" ").append(ws_status_to_msgstr(status)).append(WS_CRLF);
    resp.append("Server: ").append(REQUEST_USER_AGENT).append(WS_CRLF);
    resp.append("Connection: close" WS_CRLF);
    resp.append(WS_CRLF);
    m_sockPtr->SendData(resp.c_str(), resp.size());
    m_sockPtr->Disconnect();
    return;
  }

  // bad request!!!
  WS_STATUS status(WS_STATUS_400_Bad_Request);
  resp.append(REQUEST_PROTOCOL " ").append(ws_status_to_numstr(status)).append(" ").append(ws_status_to_msgstr(status)).append(WS_CRLF);
  resp.append("Server: ").append(REQUEST_USER_AGENT).append(WS_CRLF);
  resp.append("Connection: close" WS_CRLF);
  resp.append(WS_CRLF);
  m_sockPtr->SendData(resp.c_str(), resp.size());
  m_sockPtr->Disconnect();
}
